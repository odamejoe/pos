package com.acnoo.pospro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
