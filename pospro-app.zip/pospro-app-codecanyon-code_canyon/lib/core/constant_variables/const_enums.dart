
///___________Party_Payment_type
enum PartyOpeningBalanceType {
  due,
  advance,
}
