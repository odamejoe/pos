class LocalDataBaseSavingKey {
  static String skipOnBodingKey = 'skip_on_boding';
  static String tokenKey = 'token';
}
