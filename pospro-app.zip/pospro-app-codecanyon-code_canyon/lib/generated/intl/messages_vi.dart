// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a vi locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'vi';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "CustomerDetails": MessageLookupByLibrary.simpleMessage(
      "Chi tiết khách hàng",
    ),
    "INVOICE": MessageLookupByLibrary.simpleMessage("HÓA ĐƠN"),
    "action": MessageLookupByLibrary.simpleMessage("Hành động"),
    "actions": MessageLookupByLibrary.simpleMessage("Hành động"),
    "active": MessageLookupByLibrary.simpleMessage("Hoạt động"),
    "add": MessageLookupByLibrary.simpleMessage("Thêm"),
    "addAPurchase": MessageLookupByLibrary.simpleMessage(
      "Vui lòng thêm mua hàng",
    ),
    "addBrand": MessageLookupByLibrary.simpleMessage("thêm thương hiệu"),
    "addCategory": MessageLookupByLibrary.simpleMessage("Thêm danh mục"),
    "addContact": MessageLookupByLibrary.simpleMessage("Thêm liên hệ"),
    "addCustomer": MessageLookupByLibrary.simpleMessage(
      "Vui lòng thêm một khách hàng",
    ),
    "addCustomers": MessageLookupByLibrary.simpleMessage("Thêm khách hàng"),
    "addDelivery": MessageLookupByLibrary.simpleMessage("Thêm Giao hàng"),
    "addExpense": MessageLookupByLibrary.simpleMessage("Thêm chi phí"),
    "addExpenseCat": MessageLookupByLibrary.simpleMessage(
      "Thêm danh mục chi phí",
    ),
    "addIncome": MessageLookupByLibrary.simpleMessage("Thêm Thu nhập"),
    "addIncomeCategory": MessageLookupByLibrary.simpleMessage(
      "Thêm Danh mục Thu nhập",
    ),
    "addItems": MessageLookupByLibrary.simpleMessage("Thêm các mục"),
    "addNewAddress": MessageLookupByLibrary.simpleMessage("Thêm địa chỉ mới"),
    "addNewProduct": MessageLookupByLibrary.simpleMessage("Thêm sản phẩm mới"),
    "addNewPurchase": MessageLookupByLibrary.simpleMessage(
      "Vui lòng thêm mua hàng",
    ),
    "addNewTax": MessageLookupByLibrary.simpleMessage("Thêm thuế mới"),
    "addNote": MessageLookupByLibrary.simpleMessage("Thêm Ghi chú"),
    "addParty": MessageLookupByLibrary.simpleMessage("Thêm Đối tác"),
    "addProduct": MessageLookupByLibrary.simpleMessage(
      "Vui lòng thêm một sản phẩm",
    ),
    "addProductFirst": MessageLookupByLibrary.simpleMessage(
      "Thêm sản phẩm trước",
    ),
    "addProductSuccess": MessageLookupByLibrary.simpleMessage(
      "Tạo sản phẩm thành công!",
    ),
    "addProductWarn": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền tạo sản phẩm.",
    ),
    "addPurchase": MessageLookupByLibrary.simpleMessage("Thêm mua hàng"),
    "addSale": MessageLookupByLibrary.simpleMessage("Vui lòng thêm giảm giá"),
    "addSales": MessageLookupByLibrary.simpleMessage("Thêm bán hàng"),
    "addStock": MessageLookupByLibrary.simpleMessage("Thêm hàng tồn kho"),
    "addTax": MessageLookupByLibrary.simpleMessage("Thêm thuế"),
    "addTaxGroup": MessageLookupByLibrary.simpleMessage("Thêm nhóm thuế mới"),
    "addUnit": MessageLookupByLibrary.simpleMessage("Thêm đơn vị"),
    "addUserRole": MessageLookupByLibrary.simpleMessage(
      "Thêm Vai Trò Người Dùng",
    ),
    "addVariant": MessageLookupByLibrary.simpleMessage("Thêm biến thể"),
    "addVariantDetails": MessageLookupByLibrary.simpleMessage(
      "Thêm chi tiết biến thể",
    ),
    "addedToCart": MessageLookupByLibrary.simpleMessage("Đã thêm vào giỏ hàng"),
    "adding": MessageLookupByLibrary.simpleMessage("Đang thêm.."),
    "address": MessageLookupByLibrary.simpleMessage("Địa chỉ"),
    "admin": MessageLookupByLibrary.simpleMessage("Quản trị viên"),
    "all": MessageLookupByLibrary.simpleMessage("Tất cả"),
    "allBusinessSolutions": MessageLookupByLibrary.simpleMessage(
      "Tất cả giải pháp doanh nghiệp",
    ),
    "allBusinessolutionDescrip": MessageLookupByLibrary.simpleMessage(
      "PosPro là một giải pháp kinh doanh hoàn chỉnh với quản lý kho, tài khoản, bán hàng, chi phí và lợi nhuận/tổn thất.",
    ),
    "allTime": MessageLookupByLibrary.simpleMessage("Tất cả Thời gian"),
    "alreadyAdded": MessageLookupByLibrary.simpleMessage("Đã thêm"),
    "alreadyHaveAnAccount": MessageLookupByLibrary.simpleMessage(
      "Đã có tài khoản? ",
    ),
    "amount": MessageLookupByLibrary.simpleMessage("Số lượng"),
    "amountRoundingMethod": MessageLookupByLibrary.simpleMessage(
      "Phương pháp làm tròn số tiền",
    ),
    "amountsInWord": MessageLookupByLibrary.simpleMessage("Số tiền bằng chữ"),
    "anSMSWillBeSentToTheFollowingNumber": MessageLookupByLibrary.simpleMessage(
      "Một tin nhắn SMS sẽ được gửi đến số điện thoại sau:",
    ),
    "android": MessageLookupByLibrary.simpleMessage(
      "Hỗ trợ ứng dụng Android và iOS",
    ),
    "anewUpdateAvailable": MessageLookupByLibrary.simpleMessage(
      "Có phiên bản cập nhật mới\nVui lòng cập nhật ứng dụng của bạn",
    ),
    "appleWatch": MessageLookupByLibrary.simpleMessage("Apple Watch"),
    "apply": MessageLookupByLibrary.simpleMessage("Áp dụng"),
    "areYouSure": MessageLookupByLibrary.simpleMessage("Bạn có chắc không?"),
    "areYouSureYouWant": MessageLookupByLibrary.simpleMessage(
      "Bạn có chắc chắn muốn xóa bên này không?",
    ),
    "authorizedSignature": MessageLookupByLibrary.simpleMessage(
      "Chữ ký được ủy quyền",
    ),
    "backToHome": MessageLookupByLibrary.simpleMessage("Quay Lại Trang Chủ"),
    "balance": MessageLookupByLibrary.simpleMessage("Số dư"),
    "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
    "barcodeGen": MessageLookupByLibrary.simpleMessage("Trình tạo mã vạch"),
    "barcodeGenerator": MessageLookupByLibrary.simpleMessage(
      "Trình tạo mã vạch",
    ),
    "batch": MessageLookupByLibrary.simpleMessage("Lô hàng"),
    "batchNo": MessageLookupByLibrary.simpleMessage("Số lô"),
    "billTO": MessageLookupByLibrary.simpleMessage("Người thanh toán"),
    "billingAddress": MessageLookupByLibrary.simpleMessage(
      "Địa chỉ thanh toán",
    ),
    "brand": MessageLookupByLibrary.simpleMessage("Thương hiệu"),
    "brandName": MessageLookupByLibrary.simpleMessage("tên thương hiệu"),
    "brands": MessageLookupByLibrary.simpleMessage("Nhãn hiệu"),
    "bulk": MessageLookupByLibrary.simpleMessage("Tải lên hàng loạt"),
    "businessCat": MessageLookupByLibrary.simpleMessage("hạng thương gia"),
    "businessName": MessageLookupByLibrary.simpleMessage(
      "Tên công ty & doanh nghiệp",
    ),
    "buyPremium": MessageLookupByLibrary.simpleMessage("Mua gói cao cấp"),
    "call": MessageLookupByLibrary.simpleMessage("Gọi"),
    "camera": MessageLookupByLibrary.simpleMessage("Máy ảnh"),
    "cancel": MessageLookupByLibrary.simpleMessage("Hủy bỏ"),
    "capacity": MessageLookupByLibrary.simpleMessage("Sức chứa"),
    "cash": MessageLookupByLibrary.simpleMessage("Tiền mặt"),
    "categories": MessageLookupByLibrary.simpleMessage("Danh Mục"),
    "category": MessageLookupByLibrary.simpleMessage("Danh mục"),
    "categoryName": MessageLookupByLibrary.simpleMessage("Tên danh mục"),
    "changeAmount": MessageLookupByLibrary.simpleMessage("Số tiền trả lại"),
    "changePassword": MessageLookupByLibrary.simpleMessage("Đổi mật khẩu"),
    "checkEmail": MessageLookupByLibrary.simpleMessage("Kiểm tra email"),
    "choose": MessageLookupByLibrary.simpleMessage("Chọn"),
    "chooseCountry": MessageLookupByLibrary.simpleMessage("Chọn quốc gia"),
    "chooseCustomer": MessageLookupByLibrary.simpleMessage(
      "Chọn một khách hàng",
    ),
    "chooseSupplier": MessageLookupByLibrary.simpleMessage("Chọn nhà cung cấp"),
    "choseYourFeature": MessageLookupByLibrary.simpleMessage(
      "Chọn Chức năng của bạn",
    ),
    "choseyourfeatureDesciption": MessageLookupByLibrary.simpleMessage(
      "Các tính năng quan trọng làm cho PosPro khác biệt so với các giải pháp truyền thống.",
    ),
    "city": MessageLookupByLibrary.simpleMessage("Thành phố"),
    "cityName": MessageLookupByLibrary.simpleMessage("Tên thành phố"),
    "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
    "clear": MessageLookupByLibrary.simpleMessage("Xóa"),
    "clickToConnect": MessageLookupByLibrary.simpleMessage("Bấm để kết nối"),
    "close": MessageLookupByLibrary.simpleMessage("Đóng"),
    "code": MessageLookupByLibrary.simpleMessage("Mã"),
    "collectDue": MessageLookupByLibrary.simpleMessage("thu tiền đến hạn"),
    "collectDues": MessageLookupByLibrary.simpleMessage(
      "Vui lòng thu tiền đến hạn",
    ),
    "collectedBy": MessageLookupByLibrary.simpleMessage("Thu thập bởi:"),
    "collectedBys": MessageLookupByLibrary.simpleMessage("Thu bởi"),
    "color": MessageLookupByLibrary.simpleMessage("Màu sắc"),
    "combinationOfTheMultipleTaxes": MessageLookupByLibrary.simpleMessage(
      "Kết hợp nhiều loại thuế",
    ),
    "comingSoon": MessageLookupByLibrary.simpleMessage("Sắp có"),
    "companyAddress": MessageLookupByLibrary.simpleMessage("địa chỉ công ty"),
    "confirmDelete": MessageLookupByLibrary.simpleMessage("Xác nhận xóa"),
    "confirmPass": MessageLookupByLibrary.simpleMessage("Xác nhận mật khẩu"),
    "confirmPassword": MessageLookupByLibrary.simpleMessage(
      "Xác nhận mật khẩu",
    ),
    "confirmSMSTo": MessageLookupByLibrary.simpleMessage("Xác nhận SMS đến"),
    "congratulation": MessageLookupByLibrary.simpleMessage("Chúc mừng"),
    "connect": MessageLookupByLibrary.simpleMessage("Bấm để kết nối"),
    "connectPrinter": MessageLookupByLibrary.simpleMessage(
      "Kết nối máy in của bạn",
    ),
    "connectYourPrinter": MessageLookupByLibrary.simpleMessage(
      "Kết nối máy in của bạn",
    ),
    "contactDetials": MessageLookupByLibrary.simpleMessage("Thông tin Liên hệ"),
    "contactUs": MessageLookupByLibrary.simpleMessage("Liên Hệ Chúng Tôi"),
    "continueButton": MessageLookupByLibrary.simpleMessage("Tiếp tục"),
    "continueE": MessageLookupByLibrary.simpleMessage("Tiếp tục"),
    "cost": MessageLookupByLibrary.simpleMessage("Chi phí"),
    "country": MessageLookupByLibrary.simpleMessage("Quốc gia"),
    "create": MessageLookupByLibrary.simpleMessage("Tạo"),
    "createAFreeAccount": MessageLookupByLibrary.simpleMessage(
      "Tạo tài khoản miễn phí",
    ),
    "createAcc": MessageLookupByLibrary.simpleMessage(
      "Tạo một tài khoản miễn phí",
    ),
    "createNewPassword": MessageLookupByLibrary.simpleMessage(
      "Tạo mật khẩu mới",
    ),
    "createPdfWarn": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền tạo PDF.",
    ),
    "createSaleWarn": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền tạo bán hàng.",
    ),
    "creditLimit": MessageLookupByLibrary.simpleMessage(
      "Hạn mức tín dụng Đối tác",
    ),
    "currency": MessageLookupByLibrary.simpleMessage("Tiền tệ"),
    "custom": MessageLookupByLibrary.simpleMessage("Tùy chỉnh"),
    "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
      "Tùy chỉnh thương hiệu hóa đơn",
    ),
    "customPrint": MessageLookupByLibrary.simpleMessage("In tùy chỉnh"),
    "customer": MessageLookupByLibrary.simpleMessage("Khách hàng"),
    "customerDue": MessageLookupByLibrary.simpleMessage("Khách hàng còn nợ"),
    "customerName": MessageLookupByLibrary.simpleMessage("tên khách hàng"),
    "customerPay": MessageLookupByLibrary.simpleMessage(
      "Khách hàng thanh toán",
    ),
    "customerPhoneNumber": MessageLookupByLibrary.simpleMessage(
      "Số điện thoại khách hàng",
    ),
    "customerSignature": MessageLookupByLibrary.simpleMessage(
      "Chữ ký khách hàng",
    ),
    "dailyTransaction": MessageLookupByLibrary.simpleMessage(
      "Giao dịch Hàng ngày",
    ),
    "dashboard": MessageLookupByLibrary.simpleMessage("Bảng điều khiển"),
    "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
      "Dữ liệu đã được lưu thành công.",
    ),
    "date": MessageLookupByLibrary.simpleMessage("Ngày"),
    "dateFilterWarn": MessageLookupByLibrary.simpleMessage(
      "Ngày kết thúc không được trước ngày bắt đầu.",
    ),
    "dates": MessageLookupByLibrary.simpleMessage("Ngày:"),
    "days": MessageLookupByLibrary.simpleMessage("ngày"),
    "dealer": MessageLookupByLibrary.simpleMessage("Người buôn bán"),
    "dealerPrice": MessageLookupByLibrary.simpleMessage("Giá đại lý"),
    "delete": MessageLookupByLibrary.simpleMessage("Xóa"),
    "deleteAcc": MessageLookupByLibrary.simpleMessage("Xóa tài khoản"),
    "deleteBatchWarn": MessageLookupByLibrary.simpleMessage(
      "Bạn có chắc muốn xóa lô hàng này không?",
    ),
    "deletePartyWarn": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền xóa đối tác.",
    ),
    "deletedSuccessFully": MessageLookupByLibrary.simpleMessage(
      "Đã xóa thành công!",
    ),
    "deleting": MessageLookupByLibrary.simpleMessage("Đang xóa...."),
    "deliveryAddress": MessageLookupByLibrary.simpleMessage(
      "Địa chỉ giao hàng",
    ),
    "deliveryCharge": MessageLookupByLibrary.simpleMessage("Phí giao hàng"),
    "description": MessageLookupByLibrary.simpleMessage("Mô tả"),
    "details": MessageLookupByLibrary.simpleMessage("Chi tiết"),
    "digits": MessageLookupByLibrary.simpleMessage(
      "Mã pin 6 chữ số đã được gửi đến địa chỉ email của bạn: ",
    ),
    "disable": MessageLookupByLibrary.simpleMessage("Vô hiệu hóa"),
    "discount": MessageLookupByLibrary.simpleMessage("Giảm giá"),
    "doNotDisturb": MessageLookupByLibrary.simpleMessage("Không làm phiền"),
    "doYouWantToDeleteTheUser": MessageLookupByLibrary.simpleMessage(
      "Bạn có muốn xóa người dùng không?",
    ),
    "doYouWantToExitTheApp": MessageLookupByLibrary.simpleMessage(
      "Bạn có muốn thoát ứng dụng không?",
    ),
    "donNotHaveAnAccount": MessageLookupByLibrary.simpleMessage(
      "Bạn chưa có tài khoản?",
    ),
    "done": MessageLookupByLibrary.simpleMessage("Xong"),
    "due": MessageLookupByLibrary.simpleMessage("Quá hạn"),
    "dueAmount": MessageLookupByLibrary.simpleMessage("Số tiền đến hạn: "),
    "dueCollection": MessageLookupByLibrary.simpleMessage("Thu hồi nợ"),
    "dueList": MessageLookupByLibrary.simpleMessage("Danh sách đến hạn"),
    "dueReport": MessageLookupByLibrary.simpleMessage("báo cáo đến hạn"),
    "dueSaleWarn": MessageLookupByLibrary.simpleMessage(
      "Không cho phép bán hàng nợ cho khách hàng không đăng ký.",
    ),
    "easyToUseThePos": MessageLookupByLibrary.simpleMessage(
      "Dễ sử dụng điểm bán hàng di động",
    ),
    "easytheusedesciption": MessageLookupByLibrary.simpleMessage(
      "Ứng dụng PosPro miễn phí và dễ sử dụng. Trong thực tế, đó là một trong những hệ thống POS tốt nhất trên thế giới.",
    ),
    "edit": MessageLookupByLibrary.simpleMessage("Biên tập"),
    "editPhone": MessageLookupByLibrary.simpleMessage(
      "Chỉnh sửa số điện thoại?",
    ),
    "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
      "Chỉnh sửa hóa đơn mua hàng",
    ),
    "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
      "Chỉnh sửa hóa đơn bán hàng",
    ),
    "editSocailMedia": MessageLookupByLibrary.simpleMessage(
      "Chỉnh sửa Mạng xã hội",
    ),
    "editTax": MessageLookupByLibrary.simpleMessage("Chỉnh sửa thuế"),
    "editTaxGroup": MessageLookupByLibrary.simpleMessage("Chỉnh sửa nhóm thuế"),
    "email": MessageLookupByLibrary.simpleMessage("Địa chỉ email"),
    "emailCannotBeEmpty": MessageLookupByLibrary.simpleMessage(
      "Email không được để trống",
    ),
    "emailText": MessageLookupByLibrary.simpleMessage("E-mail"),
    "enLowStock": MessageLookupByLibrary.simpleMessage(
      "Nhập số lượng tồn kho thấp",
    ),
    "endDate": MessageLookupByLibrary.simpleMessage("Ngày kết thúc"),
    "endYourFreePlan": MessageLookupByLibrary.simpleMessage(
      "Kết thúc gói miễn phí của bạn",
    ),
    "entBatchNo": MessageLookupByLibrary.simpleMessage("Nhập số lô"),
    "enterABrandName": MessageLookupByLibrary.simpleMessage(
      "Nhập tên thương hiệu",
    ),
    "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
      "Nhập giảm giá hợp lệ",
    ),
    "enterAValidOTP": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập OTP hợp lệ",
    ),
    "enterAValidStock": MessageLookupByLibrary.simpleMessage(
      "Nhập số lượng hàng tồn kho hợp lệ",
    ),
    "enterAddress": MessageLookupByLibrary.simpleMessage("Nhập địa chỉ"),
    "enterAmount": MessageLookupByLibrary.simpleMessage("Nhập Số tiền"),
    "enterBusiness": MessageLookupByLibrary.simpleMessage(
      "Nhập tên doanh nghiệp/cửa hàng",
    ),
    "enterCapacity": MessageLookupByLibrary.simpleMessage("Nhập dung tích"),
    "enterCategoryName": MessageLookupByLibrary.simpleMessage(
      "Nhập tên danh mục",
    ),
    "enterColor": MessageLookupByLibrary.simpleMessage("Nhập màu sắc"),
    "enterCustomerPhoneNumber": MessageLookupByLibrary.simpleMessage(
      "Nhập số điện thoại khách hàng",
    ),
    "enterDealerPrice": MessageLookupByLibrary.simpleMessage("Nhập giá đại lý"),
    "enterDiscount": MessageLookupByLibrary.simpleMessage("Nhập giảm giá"),
    "enterEmail": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập địa chỉ email của bạn dưới đây để nhận Liên kết đặt lại mật khẩu.",
    ),
    "enterExpanseCategoryName": MessageLookupByLibrary.simpleMessage(
      "Nhập tên danh mục chi phí",
    ),
    "enterExpenseDate": MessageLookupByLibrary.simpleMessage(
      "Nhập ngày chi phí",
    ),
    "enterFullAddress": MessageLookupByLibrary.simpleMessage(
      "Nhập địa chỉ đầy đủ",
    ),
    "enterIncomeCategoryName": MessageLookupByLibrary.simpleMessage(
      "Nhập tên danh mục thu nhập",
    ),
    "enterManufacturerName": MessageLookupByLibrary.simpleMessage(
      "Nhập tên nhà sản xuất",
    ),
    "enterName": MessageLookupByLibrary.simpleMessage("Nhập Tên"),
    "enterNote": MessageLookupByLibrary.simpleMessage("Nhập ghi chú"),
    "enterOpeningBalance": MessageLookupByLibrary.simpleMessage(
      "Nhập số dư mở",
    ),
    "enterProductCode": MessageLookupByLibrary.simpleMessage(
      "Nhập mã sản phẩm",
    ),
    "enterProductName": MessageLookupByLibrary.simpleMessage(
      "Nhập tên sản phẩm",
    ),
    "enterPurchasePrice": MessageLookupByLibrary.simpleMessage("Nhập giá mua"),
    "enterQuantity": MessageLookupByLibrary.simpleMessage("Nhập số lượng"),
    "enterRefNumber": MessageLookupByLibrary.simpleMessage(
      "Nhập số tham chiếu",
    ),
    "enterSaltingPrice": MessageLookupByLibrary.simpleMessage("Nhập giá bán"),
    "enterSize": MessageLookupByLibrary.simpleMessage("Nhập kích thước"),
    "enterStock": MessageLookupByLibrary.simpleMessage(
      "Nhập số lượng hàng tồn kho",
    ),
    "enterTaxRates": MessageLookupByLibrary.simpleMessage("Nhập thuế suất"),
    "enterType": MessageLookupByLibrary.simpleMessage("Nhập loại"),
    "enterUserTitle": MessageLookupByLibrary.simpleMessage(
      "Nhập tiêu đề người dùng",
    ),
    "enterValidOTP": MessageLookupByLibrary.simpleMessage("Nhập OTP hợp lệ"),
    "enterVatGstNumber": MessageLookupByLibrary.simpleMessage(
      "Nhập số VAT/GST",
    ),
    "enterVatGstTitle": MessageLookupByLibrary.simpleMessage(
      "Nhập tiêu đề VAT/GST",
    ),
    "enterWeight": MessageLookupByLibrary.simpleMessage("Nhập trọng lượng"),
    "enterWholesalePrice": MessageLookupByLibrary.simpleMessage(
      "Nhập giá bán buôn",
    ),
    "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
      "Nhập địa chỉ email của bạn",
    ),
    "enterYourFullName": MessageLookupByLibrary.simpleMessage(
      "Nhập họ và tên của bạn",
    ),
    "enterYourName": MessageLookupByLibrary.simpleMessage("Nhập tên của bạn"),
    "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
      "Nhập số điện thoại của bạn",
    ),
    "errorDeletingTax": MessageLookupByLibrary.simpleMessage(
      "Lỗi khi xóa thuế",
    ),
    "expDate": MessageLookupByLibrary.simpleMessage("Ngày hết hạn"),
    "expense": MessageLookupByLibrary.simpleMessage("Chi phí"),
    "expenseCat": MessageLookupByLibrary.simpleMessage("Danh mục chi phí"),
    "expenseDate": MessageLookupByLibrary.simpleMessage("Ngày chi phí"),
    "expenseFor": MessageLookupByLibrary.simpleMessage("chi phí cho"),
    "expenseReport": MessageLookupByLibrary.simpleMessage("Báo cáo chi tiêu"),
    "expirationStatus": MessageLookupByLibrary.simpleMessage(
      "Tình trạng hết hạn",
    ),
    "expiredList": MessageLookupByLibrary.simpleMessage("Danh sách đã hết hạn"),
    "facebook": MessageLookupByLibrary.simpleMessage("Facebook"),
    "failedToDeleteTheTax": MessageLookupByLibrary.simpleMessage(
      "Không thể xóa thuế",
    ),
    "failedToGetPlatformVersion": MessageLookupByLibrary.simpleMessage(
      "Không lấy được phiên bản nền tảng.",
    ),
    "fashions": MessageLookupByLibrary.simpleMessage("Thời trang"),
    "field": MessageLookupByLibrary.simpleMessage("Trường"),
    "filter": MessageLookupByLibrary.simpleMessage("Bộ lọc"),
    "firstName": MessageLookupByLibrary.simpleMessage("Tên"),
    "folder": MessageLookupByLibrary.simpleMessage(
      "Có thể email đã bị đưa vào thư mục spam của bạn.",
    ),
    "forgotPassword": MessageLookupByLibrary.simpleMessage("Quên mật khẩu"),
    "freeDataBackup": MessageLookupByLibrary.simpleMessage(
      "Sao lưu dữ liệu miễn phí",
    ),
    "freeLifetimeUpdate": MessageLookupByLibrary.simpleMessage(
      "Cập nhật miễn phí trọn đời",
    ),
    "freePack": MessageLookupByLibrary.simpleMessage("Gói miễn phí"),
    "freePlan": MessageLookupByLibrary.simpleMessage("Gói miễn phí"),
    "fromDate": MessageLookupByLibrary.simpleMessage("Từ ngày"),
    "fullName": MessageLookupByLibrary.simpleMessage("Họ và tên"),
    "fullyPaid": MessageLookupByLibrary.simpleMessage("Thanh toán đầy đủ"),
    "gallery": MessageLookupByLibrary.simpleMessage("Phòng trưng bày"),
    "genPdfWarn": MessageLookupByLibrary.simpleMessage(
      "Không có dữ liệu để tạo PDF",
    ),
    "generatingPdf": MessageLookupByLibrary.simpleMessage("Đang tạo PDF"),
    "gotEmail": MessageLookupByLibrary.simpleMessage("Bạn đã có một email"),
    "gotIt": MessageLookupByLibrary.simpleMessage("Đã hiểu"),
    "guest": MessageLookupByLibrary.simpleMessage("Khách"),
    "haveAcc": MessageLookupByLibrary.simpleMessage(
      "Bạn co săn san để tạo một tai khoản?",
    ),
    "hintEmail": MessageLookupByLibrary.simpleMessage("Nhập địa chỉ email"),
    "hintPassword": MessageLookupByLibrary.simpleMessage("Nhập mật khẩu"),
    "home": MessageLookupByLibrary.simpleMessage("Trang chủ"),
    "image": MessageLookupByLibrary.simpleMessage("Hình ảnh"),
    "income": MessageLookupByLibrary.simpleMessage("Doanh thu"),
    "incomeCategories": MessageLookupByLibrary.simpleMessage(
      "Danh mục Thu nhập",
    ),
    "incomeDate": MessageLookupByLibrary.simpleMessage("Ngày Thu nhập"),
    "incomeFor": MessageLookupByLibrary.simpleMessage("Thu nhập Cho"),
    "incomeReport": MessageLookupByLibrary.simpleMessage("Báo cáo doanh thu"),
    "incomeReportPermission": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền xem báo cáo thu nhập.",
    ),
    "instagram": MessageLookupByLibrary.simpleMessage("Instagram"),
    "instrucation": MessageLookupByLibrary.simpleMessage("Hướng dẫn"),
    "inv": MessageLookupByLibrary.simpleMessage("Số đầu tư"),
    "inventoryPermission": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền quản lý tồn kho",
    ),
    "invoice": MessageLookupByLibrary.simpleMessage("Hóa đơn"),
    "invoiceLogo": MessageLookupByLibrary.simpleMessage("Logo hóa đơn"),
    "invoiceNumber": MessageLookupByLibrary.simpleMessage("Số hóa đơn"),
    "invoiceViewr": MessageLookupByLibrary.simpleMessage("Trình xem Hóa đơn"),
    "item": MessageLookupByLibrary.simpleMessage("Mặt hàng"),
    "itemAdded": MessageLookupByLibrary.simpleMessage("Đã thêm mục"),
    "itemsSales": MessageLookupByLibrary.simpleMessage("Doanh thu mặt hàng"),
    "lableEmail": MessageLookupByLibrary.simpleMessage("Email"),
    "lablePassword": MessageLookupByLibrary.simpleMessage("Mật khẩu"),
    "language": MessageLookupByLibrary.simpleMessage("ngôn ngữ"),
    "lastName": MessageLookupByLibrary.simpleMessage("Họ"),
    "link": MessageLookupByLibrary.simpleMessage("Liên kết"),
    "linkedIN": MessageLookupByLibrary.simpleMessage("LinkedIN"),
    "listIsEmpty": MessageLookupByLibrary.simpleMessage("Danh sách trống"),
    "loading": MessageLookupByLibrary.simpleMessage("Đang tải"),
    "logIn": MessageLookupByLibrary.simpleMessage("Đăng nhập"),
    "logInWithMail": MessageLookupByLibrary.simpleMessage(
      "Đăng nhập bằng Email",
    ),
    "logOut": MessageLookupByLibrary.simpleMessage("Đăng xuất"),
    "loginWithPhone": MessageLookupByLibrary.simpleMessage(
      "Đăng nhập bằng điện thoại",
    ),
    "lorem": MessageLookupByLibrary.simpleMessage(
      "Lorem ipsum dolor sit amet, consectetur adip gravi iscing elit. Ultricies gravida scelerisque arcu facilisis duis in.",
    ),
    "loremIpsumDolor": MessageLookupByLibrary.simpleMessage(
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Natoque aliquet et, cur eget. Tellus sapien odio aliq.",
    ),
    "loremIpsumDolorSitAmetConsecteturElitInterdumCons":
        MessageLookupByLibrary.simpleMessage(
          "Lorem ipsum dolor sit amet, consectetur elit. Interdum cons.",
        ),
    "loss": MessageLookupByLibrary.simpleMessage("Sự mất mát"),
    "lossOrProfit": MessageLookupByLibrary.simpleMessage("Lỗ/Lãi"),
    "lossProfit": MessageLookupByLibrary.simpleMessage("Lỗ/Lợi nhuận"),
    "lossProfitReport": MessageLookupByLibrary.simpleMessage(
      "Báo cáo lỗ/lợi nhuận",
    ),
    "lowStock": MessageLookupByLibrary.simpleMessage("Hàng tồn kho thấp"),
    "lowStockReport": MessageLookupByLibrary.simpleMessage(
      "Báo cáo hàng tồn kho thấp",
    ),
    "lp": MessageLookupByLibrary.simpleMessage("Mất lợi nhuận"),
    "lpDetails": MessageLookupByLibrary.simpleMessage("Chi tiết Lỗ/Lãi"),
    "manuDate": MessageLookupByLibrary.simpleMessage("Ngày sản xuất"),
    "manufactureDate": MessageLookupByLibrary.simpleMessage("Ngày sản xuất"),
    "manufacturer": MessageLookupByLibrary.simpleMessage("nhà chế tạo"),
    "masterCard": MessageLookupByLibrary.simpleMessage("Thẻ MasterCard"),
    "messege": MessageLookupByLibrary.simpleMessage("Tin nhắn"),
    "mobile": MessageLookupByLibrary.simpleMessage("di động:"),
    "mobiles": MessageLookupByLibrary.simpleMessage("Điện thoại di động"),
    "model": MessageLookupByLibrary.simpleMessage("Mẫu"),
    "moneyReceipt": MessageLookupByLibrary.simpleMessage("Biên lai thu tiền"),
    "monthly": MessageLookupByLibrary.simpleMessage("Hàng tháng"),
    "moreInfo": MessageLookupByLibrary.simpleMessage("Thêm thông tin"),
    "mrp": MessageLookupByLibrary.simpleMessage("MRP"),
    "name": MessageLookupByLibrary.simpleMessage("Tên"),
    "nameCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
      "Tên không được để trống",
    ),
    "newPassword": MessageLookupByLibrary.simpleMessage("Mật khẩu mới"),
    "next": MessageLookupByLibrary.simpleMessage("Tiếp tục"),
    "no": MessageLookupByLibrary.simpleMessage("Không"),
    "noAcc": MessageLookupByLibrary.simpleMessage("Chưa có tài khoản nào?"),
    "noData": MessageLookupByLibrary.simpleMessage("Không có dữ liệu"),
    "noDataAvailabe": MessageLookupByLibrary.simpleMessage("Không có dữ liệu"),
    "noDataFound": MessageLookupByLibrary.simpleMessage(
      "Không tìm thấy dữ liệu",
    ),
    "noDue": MessageLookupByLibrary.simpleMessage("Không có nợ"),
    "noDueSelected": MessageLookupByLibrary.simpleMessage("Chưa chọn khoản nợ"),
    "noItemSelected": MessageLookupByLibrary.simpleMessage("Chưa chọn mục nào"),
    "noMatched": MessageLookupByLibrary.simpleMessage(
      "Không tìm thấy sản phẩm phù hợp.",
    ),
    "noParty": MessageLookupByLibrary.simpleMessage("Không tìm thấy Đối tác"),
    "noProductFound": MessageLookupByLibrary.simpleMessage(
      "Không tìm thấy sản phẩm",
    ),
    "noProductSelected": MessageLookupByLibrary.simpleMessage(
      "Chưa chọn sản phẩm nào",
    ),
    "noRoleFound": MessageLookupByLibrary.simpleMessage(
      "Không Tìm Thấy Vai Trò Người Dùng",
    ),
    "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
      "Chưa chọn thuế phụ",
    ),
    "noSupplier": MessageLookupByLibrary.simpleMessage("Không có nhà cung cấp"),
    "noTransaction": MessageLookupByLibrary.simpleMessage("Không có giao dịch"),
    "notFound": MessageLookupByLibrary.simpleMessage("Không tìm thấy"),
    "notLaunch": MessageLookupByLibrary.simpleMessage(
      "Không thể mở ứng dụng điện thoại.",
    ),
    "note": MessageLookupByLibrary.simpleMessage("Ghi chú"),
    "notification": MessageLookupByLibrary.simpleMessage("Thông báo"),
    "off": MessageLookupByLibrary.simpleMessage("Tắt"),
    "on": MessageLookupByLibrary.simpleMessage("Bật"),
    "openCamera": MessageLookupByLibrary.simpleMessage("Mở camera"),
    "openingBalance": MessageLookupByLibrary.simpleMessage("Số dư đầu kỳ"),
    "opinion": MessageLookupByLibrary.simpleMessage("Nhập ý kiến của bạn"),
    "outOfStock": MessageLookupByLibrary.simpleMessage("Hết hàng"),
    "packFeatures": MessageLookupByLibrary.simpleMessage("Tính năng gói"),
    "package": MessageLookupByLibrary.simpleMessage("Gói"),
    "paid": MessageLookupByLibrary.simpleMessage("Trả"),
    "paidAmount": MessageLookupByLibrary.simpleMessage("Số tiền thanh toán"),
    "paidBy": MessageLookupByLibrary.simpleMessage("Thanh toán bởi"),
    "paidVia": MessageLookupByLibrary.simpleMessage("Đã thanh toán qua"),
    "parties": MessageLookupByLibrary.simpleMessage("Bên thứ ba"),
    "partyCreateWarn": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền tạo Đối tác.",
    ),
    "partyList": MessageLookupByLibrary.simpleMessage("Danh sách các bên"),
    "password": MessageLookupByLibrary.simpleMessage("Mật khẩu"),
    "passwordCannotBeEmpty": MessageLookupByLibrary.simpleMessage(
      "Mật khẩu không được để trống",
    ),
    "passwordsDoNotMatch": MessageLookupByLibrary.simpleMessage(
      "Mật khẩu không khớp",
    ),
    "payForSubscribe": MessageLookupByLibrary.simpleMessage(
      "Thanh toán để đăng ký",
    ),
    "payableAmount": MessageLookupByLibrary.simpleMessage("Số tiền phải trả"),
    "payment": MessageLookupByLibrary.simpleMessage("Thanh toán"),
    "paymentComplete": MessageLookupByLibrary.simpleMessage(
      "Thanh toán hoàn thành",
    ),
    "paymentFailed": MessageLookupByLibrary.simpleMessage(
      "Thanh toán thất bại",
    ),
    "paymentFailedPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Thanh toán thất bại. Vui lòng thử lại.",
    ),
    "paymentGateway": MessageLookupByLibrary.simpleMessage("Cổng thanh toán"),
    "paymentMethods": MessageLookupByLibrary.simpleMessage(
      "Phương thức thanh toán",
    ),
    "paymentSuccess": MessageLookupByLibrary.simpleMessage(
      "Thanh toán thành công",
    ),
    "paymentTypeHint": MessageLookupByLibrary.simpleMessage(
      "Vui lòng chọn phương thức thanh toán",
    ),
    "paymentTypes": MessageLookupByLibrary.simpleMessage(
      "Hình thức thanh toán",
    ),
    "paymentWasSuccessful": MessageLookupByLibrary.simpleMessage(
      "Thanh toán đã thành công!",
    ),
    "paymentsAmount": MessageLookupByLibrary.simpleMessage(
      "Số tiền thanh toán",
    ),
    "paypalPay": MessageLookupByLibrary.simpleMessage("Thanh toán bằng PayPal"),
    "permissionNotGranted": MessageLookupByLibrary.simpleMessage(
      "Không được cấp quyền!",
    ),
    "phone": MessageLookupByLibrary.simpleMessage("Số điện thoại"),
    "phoneNotAvail": MessageLookupByLibrary.simpleMessage(
      "Số điện thoại không có sẵn.",
    ),
    "phoneNumber": MessageLookupByLibrary.simpleMessage("Số điện thoại"),
    "phoneVerification": MessageLookupByLibrary.simpleMessage(
      "Xác minh điện thoại",
    ),
    "phonee": MessageLookupByLibrary.simpleMessage("Điện thoại:"),
    "pickEndDate": MessageLookupByLibrary.simpleMessage("Chọn ngày kết thúc"),
    "pickStartDate": MessageLookupByLibrary.simpleMessage("Chọn ngày bắt đầu"),
    "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
      "Vui lòng thêm số lượng",
    ),
    "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
      "Vui lòng kết nối máy in trước",
    ),
    "pleaseConnectYourBlutohPrinter": MessageLookupByLibrary.simpleMessage(
      "Vui lòng kết nối máy in Bluetooth của bạn",
    ),
    "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập mật khẩu dài hơn",
    ),
    "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập mật khẩu xác nhận",
    ),
    "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập mật khẩu",
    ),
    "pleaseEnterAValidBrandName": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập tên thương hiệu hợp lệ",
    ),
    "pleaseEnterAValidBusinessName": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập tên doanh nghiệp hợp lệ",
    ),
    "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập email hợp lệ",
    ),
    "pleaseEnterAValidName": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập tên hợp lệ",
    ),
    "pleaseEnterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập số điện thoại hợp lệ",
    ),
    "pleaseEnterAValidProductName": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập tên sản phẩm hợp lệ",
    ),
    "pleaseEnterAValidPurchasePrice": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập giá mua hợp lệ",
    ),
    "pleaseEnterAValidSalePrice": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập giá bán hợp lệ",
    ),
    "pleaseEnterAValidUnitName": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập tên đơn vị hợp lệ",
    ),
    "pleaseEnterAmount": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập số tiền",
    ),
    "pleaseEnterName": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập tên",
    ),
    "pleaseEnterTheOTP": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập OTP",
    ),
    "pleaseEnterUnitName": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập tên đơn vị",
    ),
    "pleaseEnterValidPhoneAndNameFirst": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập số điện thoại và tên hợp lệ trước",
    ),
    "pleaseEnterYourDetails": MessageLookupByLibrary.simpleMessage(
      "Vui lòng nhập thông tin của bạn.",
    ),
    "pleaseMakeASaleFirst": MessageLookupByLibrary.simpleMessage(
      "Vui lòng thực hiện một giao dịch bán hàng trước",
    ),
    "pleaseSelectACategory": MessageLookupByLibrary.simpleMessage(
      "Vui lòng chọn một danh mục",
    ),
    "pleaseSelectAExpenseCategory": MessageLookupByLibrary.simpleMessage(
      "Vui lòng chọn danh mục chi phí",
    ),
    "posSale": MessageLookupByLibrary.simpleMessage("Bán hàng POS"),
    "powerdedByAcnoo": MessageLookupByLibrary.simpleMessage(
      "Được cung cấp bởi Acnoo",
    ),
    "poweredBy": MessageLookupByLibrary.simpleMessage("Được cung cấp bởi"),
    "premiumCustomerSupport": MessageLookupByLibrary.simpleMessage(
      "Hỗ trợ ứng dụng Android và iOS",
    ),
    "premiumPlan": MessageLookupByLibrary.simpleMessage("Gói cao cấp"),
    "previewPdf": MessageLookupByLibrary.simpleMessage("Xem trước PDF"),
    "previousDue": MessageLookupByLibrary.simpleMessage("Đến hạn trước"),
    "previousPayAmount": MessageLookupByLibrary.simpleMessage(
      "Số tiền thanh toán trước đót",
    ),
    "price": MessageLookupByLibrary.simpleMessage("Giá"),
    "priceWarn": MessageLookupByLibrary.simpleMessage(
      "Giá không được để trống",
    ),
    "print": MessageLookupByLibrary.simpleMessage("In"),
    "printing": MessageLookupByLibrary.simpleMessage("Tùy chọn in"),
    "printingInvoice": MessageLookupByLibrary.simpleMessage("Đang in hóa đơn"),
    "printingOption": MessageLookupByLibrary.simpleMessage("Tùy chọn in"),
    "product": MessageLookupByLibrary.simpleMessage("Sản phẩm"),
    "productBrand": MessageLookupByLibrary.simpleMessage(
      "Thương hiệu sản phẩm",
    ),
    "productCategory": MessageLookupByLibrary.simpleMessage(
      "Danh mục sản phẩm",
    ),
    "productCode": MessageLookupByLibrary.simpleMessage("Mã sản phẩm"),
    "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
      "Mã sản phẩm là bắt buộc",
    ),
    "productDetails": MessageLookupByLibrary.simpleMessage("Chi tiết sản phẩm"),
    "productList": MessageLookupByLibrary.simpleMessage("danh sách sản phẩm"),
    "productName": MessageLookupByLibrary.simpleMessage("Tên sản phẩm"),
    "productNotFound": MessageLookupByLibrary.simpleMessage(
      "Không tìm thấy sản phẩm",
    ),
    "productSetting": MessageLookupByLibrary.simpleMessage("Cài đặt sản phẩm"),
    "productUnit": MessageLookupByLibrary.simpleMessage("Đơn vị sản phẩm"),
    "products": MessageLookupByLibrary.simpleMessage("Sản phẩm"),
    "profile": MessageLookupByLibrary.simpleMessage("Hồ sơ"),
    "profileEdit": MessageLookupByLibrary.simpleMessage("Chỉnh sửa hồ sơ"),
    "profit": MessageLookupByLibrary.simpleMessage("Lợi nhuận"),
    "profitLoss": MessageLookupByLibrary.simpleMessage("Lãi và lỗ"),
    "profitMargin": MessageLookupByLibrary.simpleMessage("Lợi nhuận (%)"),
    "promo": MessageLookupByLibrary.simpleMessage("Khuyến mãi"),
    "promoCode": MessageLookupByLibrary.simpleMessage("Mã Khuyến Mãi"),
    "purchase": MessageLookupByLibrary.simpleMessage("Mua"),
    "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Cảnh báo Mua hàng"),
    "purchaseBy": MessageLookupByLibrary.simpleMessage("Mua bởi:"),
    "purchaseConfirmed": MessageLookupByLibrary.simpleMessage(
      "Mua hàng đã xác nhận",
    ),
    "purchaseDetails": MessageLookupByLibrary.simpleMessage(
      "Chi tiết mua hàng",
    ),
    "purchaseEx": MessageLookupByLibrary.simpleMessage("Giá mua chưa thuế"),
    "purchaseExReq": MessageLookupByLibrary.simpleMessage(
      "Yêu cầu giá mua chưa thuế",
    ),
    "purchaseIn": MessageLookupByLibrary.simpleMessage(
      "Giá mua đã bao gồm thuế",
    ),
    "purchaseInReq": MessageLookupByLibrary.simpleMessage(
      "Yêu cầu giá mua đã bao gồm thuế",
    ),
    "purchaseList": MessageLookupByLibrary.simpleMessage("Danh sách mua hàng"),
    "purchaseNow": MessageLookupByLibrary.simpleMessage("Mua Ngay"),
    "purchasePremium": MessageLookupByLibrary.simpleMessage("Mua gói cao cấp"),
    "purchasePrice": MessageLookupByLibrary.simpleMessage("Giá mua"),
    "purchaseReport": MessageLookupByLibrary.simpleMessage("Báo cáo mua hàng"),
    "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
      "Báo cáo Trả hàng Mua",
    ),
    "purchaseUpdateWarn": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền cập nhật đơn mua hàng.",
    ),
    "purchaseWarn": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền tạo đơn mua hàng.",
    ),
    "purchased": MessageLookupByLibrary.simpleMessage("Đã mua"),
    "purchasedBy": MessageLookupByLibrary.simpleMessage("Được mua bởi"),
    "qty": MessageLookupByLibrary.simpleMessage("Số lượng"),
    "quantity": MessageLookupByLibrary.simpleMessage("Số lượng"),
    "quickOver": MessageLookupByLibrary.simpleMessage("Tổng quan nhanh"),
    "quickOverview": MessageLookupByLibrary.simpleMessage("Tổng quan nhanh"),
    "receipt": MessageLookupByLibrary.simpleMessage("Biên lai/Hóa đơn"),
    "receivedAmount": MessageLookupByLibrary.simpleMessage("Số tiền nhận được"),
    "recentTransaction": MessageLookupByLibrary.simpleMessage(
      "Giao dịch gần đây",
    ),
    "recivethePin": MessageLookupByLibrary.simpleMessage("Nhận mã PIN"),
    "referenceNo": MessageLookupByLibrary.simpleMessage("Số tham chiếu"),
    "register": MessageLookupByLibrary.simpleMessage("Đăng ký"),
    "registerTitle": MessageLookupByLibrary.simpleMessage(
      "Chúng tôi cần đăng ký điện thoại của bạn mà không cần bắt đầu!",
    ),
    "remainingDue": MessageLookupByLibrary.simpleMessage("Còn nợ lại"),
    "rememberMe": MessageLookupByLibrary.simpleMessage("Ghi nhớ tôi"),
    "rememberMeLater": MessageLookupByLibrary.simpleMessage("Nhớ tôi sau"),
    "reports": MessageLookupByLibrary.simpleMessage("Báo cáo"),
    "resendIn": MessageLookupByLibrary.simpleMessage("Gửi lại OTP trong "),
    "resendOTP": MessageLookupByLibrary.simpleMessage("Gửi lại OTP"),
    "reset": MessageLookupByLibrary.simpleMessage(
      "Đặt lại mật khẩu bằng email hoặc số điện thoại của bạn",
    ),
    "resetPassword": MessageLookupByLibrary.simpleMessage(
      "Đặt lại mật khẩu để khôi phục và đăng nhập vào tài khoản của bạn",
    ),
    "retailer": MessageLookupByLibrary.simpleMessage("nhà bán lẻ"),
    "retur": MessageLookupByLibrary.simpleMessage("Trả hàng"),
    "returnAmount": MessageLookupByLibrary.simpleMessage("Số tiền trả lại"),
    "returned": MessageLookupByLibrary.simpleMessage("Đã Trả Lại"),
    "returnedDate": MessageLookupByLibrary.simpleMessage("Ngày trả lại"),
    "returnedItem": MessageLookupByLibrary.simpleMessage("Mặt hàng trả lại"),
    "rounding": MessageLookupByLibrary.simpleMessage("Làm tròn"),
    "roundingTotal": MessageLookupByLibrary.simpleMessage("Tổng đã làm tròn"),
    "roundings": MessageLookupByLibrary.simpleMessage("Làm tròn (+/-)"),
    "sale": MessageLookupByLibrary.simpleMessage("Doanh thu"),
    "saleBy": MessageLookupByLibrary.simpleMessage("Bán bởi"),
    "saleList": MessageLookupByLibrary.simpleMessage("Danh sách bán hàng"),
    "salePrice": MessageLookupByLibrary.simpleMessage("Giá bán"),
    "saleReq": MessageLookupByLibrary.simpleMessage("Yêu cầu giá bán"),
    "sales": MessageLookupByLibrary.simpleMessage("Bán hàng"),
    "salesBy": MessageLookupByLibrary.simpleMessage("Bán bởi:"),
    "salesDetails": MessageLookupByLibrary.simpleMessage("Chi tiết bán hàng"),
    "salesList": MessageLookupByLibrary.simpleMessage("Danh sách bán hàng"),
    "salesPurchaseOverview": MessageLookupByLibrary.simpleMessage(
      "Tổng quan doanh thu & mua hàng",
    ),
    "salesReport": MessageLookupByLibrary.simpleMessage("Báo cáo bán hàng"),
    "salesReturnReport": MessageLookupByLibrary.simpleMessage(
      "Báo cáo Trả hàng Bán",
    ),
    "salesSetting": MessageLookupByLibrary.simpleMessage("Cài đặt bán hàng"),
    "save": MessageLookupByLibrary.simpleMessage("Cứu"),
    "saveNPublish": MessageLookupByLibrary.simpleMessage("Lưu và xuất bản"),
    "saveSetting": MessageLookupByLibrary.simpleMessage("Lưu cài đặt"),
    "saveVariant": MessageLookupByLibrary.simpleMessage("Lưu biến thể"),
    "scanCode": MessageLookupByLibrary.simpleMessage("Quét mã QR sản phẩm"),
    "search": MessageLookupByLibrary.simpleMessage("Tìm kiếm"),
    "searchH": MessageLookupByLibrary.simpleMessage("Tìm kiếm ở đây...."),
    "searchProduct": MessageLookupByLibrary.simpleMessage("Tìm kiếm Sản phẩm"),
    "searchWith": MessageLookupByLibrary.simpleMessage("Tìm kiếm..."),
    "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
      "Xem tất cả mã khuyến mãi",
    ),
    "select": MessageLookupByLibrary.simpleMessage("Lựa chọn"),
    "selectABrand": MessageLookupByLibrary.simpleMessage("Chọn thương hiệu"),
    "selectAInvoice": MessageLookupByLibrary.simpleMessage("Chọn hóa đơn"),
    "selectBusinessCategory": MessageLookupByLibrary.simpleMessage(
      "Chọn danh mục doanh nghiệp",
    ),
    "selectCategory": MessageLookupByLibrary.simpleMessage("Chọn Danh mục"),
    "selectCustomer": MessageLookupByLibrary.simpleMessage("Chọn khách hàng"),
    "selectDate": MessageLookupByLibrary.simpleMessage("Chọn ngày"),
    "selectFDate": MessageLookupByLibrary.simpleMessage("Chọn ngày bắt đầu"),
    "selectLang": MessageLookupByLibrary.simpleMessage("Chọn ngôn ngữ của bạn"),
    "selectModel": MessageLookupByLibrary.simpleMessage("Chọn mẫu"),
    "selectOne": MessageLookupByLibrary.simpleMessage("Chọn một"),
    "selectProductCategory": MessageLookupByLibrary.simpleMessage(
      "Chọn danh mục sản phẩm",
    ),
    "selectProductUnit": MessageLookupByLibrary.simpleMessage(
      "Chọn đơn vị sản phẩm",
    ),
    "selectTax": MessageLookupByLibrary.simpleMessage("Chọn thuế"),
    "selectToDate": MessageLookupByLibrary.simpleMessage("Chọn ngày kết thúc"),
    "selectVariations": MessageLookupByLibrary.simpleMessage("Chọn biến thể: "),
    "sellAll": MessageLookupByLibrary.simpleMessage("Bán tất cả >"),
    "sellsBy": MessageLookupByLibrary.simpleMessage("Bán bởi"),
    "send": MessageLookupByLibrary.simpleMessage("Gửi"),
    "sendCode": MessageLookupByLibrary.simpleMessage("Gửi mã"),
    "sendEmail": MessageLookupByLibrary.simpleMessage(
      "Chúng tôi đã gửi Email hướng dẫn cách đặt lại mật khẩu tới:",
    ),
    "sendLink": MessageLookupByLibrary.simpleMessage("Gửi liên kết đặt lại"),
    "sendMessage": MessageLookupByLibrary.simpleMessage("Gửi Tin Nhắn"),
    "sendSMS": MessageLookupByLibrary.simpleMessage("Gửi SMS"),
    "sendSms": MessageLookupByLibrary.simpleMessage("Gửi tin nhắn SMS"),
    "sendYourEmail": MessageLookupByLibrary.simpleMessage("Gửi Email Của Bạn"),
    "setUpDesc": MessageLookupByLibrary.simpleMessage(
      "Cập nhật hồ sơ của bạn để kết nối bác sĩ của bạn với ấn tượng tốt hơn",
    ),
    "setUpNewPassword": MessageLookupByLibrary.simpleMessage(
      "Thiết lập mật khẩu mới",
    ),
    "setUpProfile": MessageLookupByLibrary.simpleMessage(
      "Thiết lập hồ sơ của bạn",
    ),
    "setting": MessageLookupByLibrary.simpleMessage("Cài đặt"),
    "share": MessageLookupByLibrary.simpleMessage("Chia sẻ"),
    "shippingAddress": MessageLookupByLibrary.simpleMessage(
      "Địa chỉ giao hàng",
    ),
    "shippingCharge": MessageLookupByLibrary.simpleMessage("Phí vận chuyển"),
    "shopOpeningBalance": MessageLookupByLibrary.simpleMessage(
      "Số dư mở cửa hàng",
    ),
    "shopRemainingBalance": MessageLookupByLibrary.simpleMessage(
      "Số dư còn lại của cửa hàng",
    ),
    "showCode": MessageLookupByLibrary.simpleMessage("Hiển thị mã"),
    "showName": MessageLookupByLibrary.simpleMessage("Hiển thị tên"),
    "showPrice": MessageLookupByLibrary.simpleMessage("Hiển thị giá"),
    "signIn": MessageLookupByLibrary.simpleMessage("Đăng nhập"),
    "signUp": MessageLookupByLibrary.simpleMessage("Đăng ký"),
    "single": MessageLookupByLibrary.simpleMessage("Đơn lẻ"),
    "size": MessageLookupByLibrary.simpleMessage("Kích thước"),
    "skip": MessageLookupByLibrary.simpleMessage("Bỏ qua"),
    "skipTheUpdate": MessageLookupByLibrary.simpleMessage("Bỏ qua cập nhật"),
    "sku": MessageLookupByLibrary.simpleMessage("SKU / Mã"),
    "sl": MessageLookupByLibrary.simpleMessage("STT"),
    "smartWatch": MessageLookupByLibrary.simpleMessage("Đồng hồ thông minh"),
    "socialMarketing": MessageLookupByLibrary.simpleMessage("Marketing Xã hội"),
    "somethingIs": MessageLookupByLibrary.simpleMessage("Có gì đó"),
    "staffLogin": MessageLookupByLibrary.simpleMessage("Đăng nhập nhân viên"),
    "startDate": MessageLookupByLibrary.simpleMessage("Ngày bắt đầu"),
    "startNewSale": MessageLookupByLibrary.simpleMessage(
      "Bắt đầu Bán hàng mới",
    ),
    "state": MessageLookupByLibrary.simpleMessage("Bang/ Tỉnh"),
    "stateName": MessageLookupByLibrary.simpleMessage("Tên bang/ tỉnh"),
    "status": MessageLookupByLibrary.simpleMessage("Trạng thái"),
    "stillUnpaid": MessageLookupByLibrary.simpleMessage("Vẫn chưa thanh toán"),
    "stock": MessageLookupByLibrary.simpleMessage("Cổ phần"),
    "stockList": MessageLookupByLibrary.simpleMessage("Danh mục chứng khoán"),
    "stockReport": MessageLookupByLibrary.simpleMessage("Báo cáo hàng tồn kho"),
    "stockValue": MessageLookupByLibrary.simpleMessage("Giá trị hàng tồn kho"),
    "stockWarn": MessageLookupByLibrary.simpleMessage(
      "Tồn kho phải ít nhất là 1",
    ),
    "stocks": MessageLookupByLibrary.simpleMessage("Hàng tồn kho: "),
    "subTaxList": MessageLookupByLibrary.simpleMessage("Danh sách thuế phụ"),
    "subTaxes": MessageLookupByLibrary.simpleMessage("Thuế phụ"),
    "subTotal": MessageLookupByLibrary.simpleMessage("Tổng phụ"),
    "submit": MessageLookupByLibrary.simpleMessage("Gửi"),
    "subscription": MessageLookupByLibrary.simpleMessage("Đăng ký"),
    "subtotal": MessageLookupByLibrary.simpleMessage("Tạm tính"),
    "successfullyPaid": MessageLookupByLibrary.simpleMessage(
      "Đã thanh toán thành công",
    ),
    "supplerPay": MessageLookupByLibrary.simpleMessage(
      "Nhà cung cấp thanh toán",
    ),
    "supplier": MessageLookupByLibrary.simpleMessage("nhà cung cấp"),
    "supplierDetails": MessageLookupByLibrary.simpleMessage(
      "Thông tin Nhà cung cấp",
    ),
    "supplierName": MessageLookupByLibrary.simpleMessage("tên đệm"),
    "taxGroup": MessageLookupByLibrary.simpleMessage("Nhóm thuế"),
    "taxPercent": MessageLookupByLibrary.simpleMessage("Phần trăm thuế"),
    "taxRates": MessageLookupByLibrary.simpleMessage("Thuế suất"),
    "taxRatesMangeYourTaxRates": MessageLookupByLibrary.simpleMessage(
      "Thuế suất - Quản lý thuế suất của bạn",
    ),
    "taxType": MessageLookupByLibrary.simpleMessage("Loại thuế"),
    "taxWithSingleMultipleTaxType": MessageLookupByLibrary.simpleMessage(
      "Thuế có một/nhiều loại thuế",
    ),
    "thakYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
      "Cảm ơn bạn đã mua hàng",
    ),
    "thankYouForYourDuePayment": MessageLookupByLibrary.simpleMessage(
      "Cảm ơn bạn đã thanh toán đúng hạn",
    ),
    "thisMonth": MessageLookupByLibrary.simpleMessage("Tháng này"),
    "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
      "Sản phẩm này đã được thêm!",
    ),
    "thisWeek": MessageLookupByLibrary.simpleMessage("Tuần này"),
    "thisYear": MessageLookupByLibrary.simpleMessage("Năm nay"),
    "toDate": MessageLookupByLibrary.simpleMessage("đến nay"),
    "today": MessageLookupByLibrary.simpleMessage("Hôm nay"),
    "todaySummary": MessageLookupByLibrary.simpleMessage("Tóm tắt hôm nay"),
    "total": MessageLookupByLibrary.simpleMessage("Tổng cộng"),
    "totalAmount": MessageLookupByLibrary.simpleMessage("Tổng cộng"),
    "totalCategories": MessageLookupByLibrary.simpleMessage("Tổng số danh mục"),
    "totalDue": MessageLookupByLibrary.simpleMessage("Tổng còn nợ"),
    "totalDueAmount": MessageLookupByLibrary.simpleMessage(
      "Tổng số tiền còn nợ",
    ),
    "totalExpense": MessageLookupByLibrary.simpleMessage("Tổng chi phí"),
    "totalIncome": MessageLookupByLibrary.simpleMessage("Tổng doanh thu"),
    "totalItems": MessageLookupByLibrary.simpleMessage("Tổng số mặt hàng"),
    "totalLoss": MessageLookupByLibrary.simpleMessage("Tổng thiệt hại"),
    "totalPayable": MessageLookupByLibrary.simpleMessage("Tổng cần thanh toán"),
    "totalPrice": MessageLookupByLibrary.simpleMessage("Tổng giá"),
    "totalProduct": MessageLookupByLibrary.simpleMessage("Tổng số sản phẩm"),
    "totalProfit": MessageLookupByLibrary.simpleMessage("Tổng lợi nhuận"),
    "totalPurchase": MessageLookupByLibrary.simpleMessage("Tổng mua hàng"),
    "totalReturnAmount": MessageLookupByLibrary.simpleMessage(
      "Tổng Số Tiền Được Trả Lại",
    ),
    "totalReturned": MessageLookupByLibrary.simpleMessage(
      "Tổng cộng đã trả lại",
    ),
    "totalSales": MessageLookupByLibrary.simpleMessage("Tổng doanh thu"),
    "totalVat": MessageLookupByLibrary.simpleMessage("Tổng VAT"),
    "totall": MessageLookupByLibrary.simpleMessage("Tổng:"),
    "tranSacOver": MessageLookupByLibrary.simpleMessage("Tổng quan giao dịch"),
    "transactions": MessageLookupByLibrary.simpleMessage("Giao dịch"),
    "tryAgain": MessageLookupByLibrary.simpleMessage("Thử lại"),
    "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
    "type": MessageLookupByLibrary.simpleMessage("Loại"),
    "typeSelect": MessageLookupByLibrary.simpleMessage("Chọn loại"),
    "unPaid": MessageLookupByLibrary.simpleMessage("Chưa thanh toán"),
    "unitName": MessageLookupByLibrary.simpleMessage("Tên bài"),
    "unitPirce": MessageLookupByLibrary.simpleMessage("Giá đơn vị"),
    "unitPrice": MessageLookupByLibrary.simpleMessage("Đơn giá"),
    "units": MessageLookupByLibrary.simpleMessage("Các đơn vị"),
    "unlimited": MessageLookupByLibrary.simpleMessage("Vô hạn"),
    "unlimitedUsage": MessageLookupByLibrary.simpleMessage(
      "Sử dụng không giới hạn",
    ),
    "unlimitedUsagesOfOurPackage": MessageLookupByLibrary.simpleMessage(
      "Sử dụng không giới hạn gói của chúng tôi👇",
    ),
    "update": MessageLookupByLibrary.simpleMessage("Cập nhật"),
    "updateContact": MessageLookupByLibrary.simpleMessage("Cập nhật liên hệ"),
    "updateFailed": MessageLookupByLibrary.simpleMessage(
      "Cập nhật tồn kho thất bại",
    ),
    "updateNow": MessageLookupByLibrary.simpleMessage("Cập nhật bây giờ"),
    "updatePartyWarn": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền cập nhật đối tác.",
    ),
    "updateProduct": MessageLookupByLibrary.simpleMessage("Cập nhật sản phẩm"),
    "updateProductSuccess": MessageLookupByLibrary.simpleMessage(
      "Cập nhật sản phẩm thành công!",
    ),
    "updateProductWarn": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền cập nhật sản phẩm.",
    ),
    "updateProfile": MessageLookupByLibrary.simpleMessage(
      "Cập nhật hồ sơ của bạn",
    ),
    "updateSaleWarn": MessageLookupByLibrary.simpleMessage(
      "Bạn không có quyền cập nhật bán hàng.",
    ),
    "updateSuccess": MessageLookupByLibrary.simpleMessage(
      "Cập nhật thành công",
    ),
    "updateYourProfile": MessageLookupByLibrary.simpleMessage(
      "Cập nhật hồ sơ của bạn để kết nối khách hàng của bạn với ấn tượng tốt hơn",
    ),
    "updateYourSubscription": MessageLookupByLibrary.simpleMessage(
      "Cập nhật đăng ký của bạn",
    ),
    "updating": MessageLookupByLibrary.simpleMessage("Đang cập nhật..."),
    "upgradeNow": MessageLookupByLibrary.simpleMessage("Nâng cấp ngay"),
    "upload": MessageLookupByLibrary.simpleMessage("Tải lên"),
    "uploadImage": MessageLookupByLibrary.simpleMessage("Tải ảnh lên"),
    "useGallery": MessageLookupByLibrary.simpleMessage("Sử dụng thư viện ảnh"),
    "useTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
      "Tiêu đề người dùng không được để trống",
    ),
    "userRole": MessageLookupByLibrary.simpleMessage("Vai trò người dùng"),
    "userRoleDetails": MessageLookupByLibrary.simpleMessage(
      "Chi tiết vai trò người dùng",
    ),
    "userTitle": MessageLookupByLibrary.simpleMessage("Tiêu đề người dùng"),
    "variantAdded": MessageLookupByLibrary.simpleMessage(
      "Biến thể đã được thêm thành công!",
    ),
    "variantDelete": MessageLookupByLibrary.simpleMessage(
      "Biến thể đã bị xóa thành công!",
    ),
    "vat": MessageLookupByLibrary.simpleMessage("VAT"),
    "vatAndTax": MessageLookupByLibrary.simpleMessage("VAT và Thuế"),
    "vatGstNumber": MessageLookupByLibrary.simpleMessage("Số VAT/GST"),
    "vatGstTitle": MessageLookupByLibrary.simpleMessage("Tiêu đề VAT/GST"),
    "vatNumber": MessageLookupByLibrary.simpleMessage("Số VAT"),
    "verification": MessageLookupByLibrary.simpleMessage("Xác minh"),
    "verify": MessageLookupByLibrary.simpleMessage("Xác minh"),
    "verifyYourEmail": MessageLookupByLibrary.simpleMessage(
      "Xác minh email của bạn",
    ),
    "verityEmail": MessageLookupByLibrary.simpleMessage("Xác minh email"),
    "view": MessageLookupByLibrary.simpleMessage("Xem chi tiết"),
    "viewAll": MessageLookupByLibrary.simpleMessage("Xem tất cả"),
    "walkInCustomer": MessageLookupByLibrary.simpleMessage(
      "Khách hàng đến cửa hàng",
    ),
    "weHaveSentAConfirmationEmailTo": MessageLookupByLibrary.simpleMessage(
      "Chúng tôi đã gửi một email xác nhận đến",
    ),
    "weSentAnOTPInYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
      "Chúng tôi đã gửi một OTP đến số điện thoại của bạn",
    ),
    "weekly": MessageLookupByLibrary.simpleMessage("Hàng tuần"),
    "weight": MessageLookupByLibrary.simpleMessage("Trọng lượng"),
    "welcomeBack": MessageLookupByLibrary.simpleMessage("Chào mừng trở lại!"),
    "whatNew": MessageLookupByLibrary.simpleMessage("Có gì mới"),
    "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Giá sỉ"),
    "wholesaler": MessageLookupByLibrary.simpleMessage("người bán buôn"),
    "willBeAddedSoon": MessageLookupByLibrary.simpleMessage(
      "Sẽ được thêm vào sớm",
    ),
    "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
      "Viết tin nhắn của bạn ở đây",
    ),
    "writerTaxHere": MessageLookupByLibrary.simpleMessage(
      "Viết văn bản vào đây...",
    ),
    "yearly": MessageLookupByLibrary.simpleMessage("Hàng năm"),
    "yes": MessageLookupByLibrary.simpleMessage("Có"),
    "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
      "Bạn không thể thanh toán nhiều hơn số tiền còn nợ",
    ),
    "youHaveToGivePermission": MessageLookupByLibrary.simpleMessage(
      "Bạn phải cấp quyền",
    ),
    "youRUsing": MessageLookupByLibrary.simpleMessage("Bạn đang sử dụng "),
    "youWantTodeletetheProduct": MessageLookupByLibrary.simpleMessage(
      "Bạn có muốn xóa sản phẩm này không?",
    ),
    "yourFree": MessageLookupByLibrary.simpleMessage(
      "Gói miễn phí của bạn sắp hết, mua gói tiếp theo của bạn. Cảm ơn.",
    ),
    "yourPack": MessageLookupByLibrary.simpleMessage("Gói của bạn"),
    "yourPackageExpiredInDays": MessageLookupByLibrary.simpleMessage(
      "Gói Của Bạn Sẽ Hết Hạn Trong 5 Ngày",
    ),
    "yourPackageExpiredToday": MessageLookupByLibrary.simpleMessage(
      "Gói Của Bạn Sẽ Hết Hạn Hôm Nay\n\nVui Lòng Mua Lại",
    ),
    "zip": MessageLookupByLibrary.simpleMessage("Mã bưu điện"),
    "zipCode": MessageLookupByLibrary.simpleMessage("Nhập mã bưu điện"),
  };
}
